<html>
<head>
<title>
    my first form
</title>
<body>
<form action="phpdata.php" method="post">
    <input type="text" name="name">
    <input type="radio" name="gender" value="f">female
    <input type="radio" name="gender" value="m">male
    <input type="radio" name="gender" value="o">other
    <input type="submit">confirm
</form>
</body>
</html>
