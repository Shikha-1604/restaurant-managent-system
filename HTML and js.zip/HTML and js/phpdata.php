<?php
$name=$_POST["name"];
$gender=$_POST["gender"];
$conn=new mysqli('localhost','root','','test');
if($conn->connect_error){
die('connection failed :'.$conn->connect_error);
}
else{
$stmt=$conn->prepare("insert into testing("name","gender")values(?,?)");
$stmt->bind_param("ss",$name,$gender);
$stmt->execute();
echo "registration successfully done.........";
}
$stmt->close();
$conn->close();

?>