var c;
function popup()
{
	document.write(name);
	}

function scrollpage()
{
	window.scrollTo(0,0);
}


function tocreate()
{
		document.write();
		window.location.replace("signup.html");
		
}



function tologin()
{
	document.write();
	window.location.replace("login.html");
		
}

function dis()
{
				scrollpage();
			alert("you need to login/signup first");
			document.getElementById("s").style.fontSize="40px";
			document.getElementById("l").style.fontSize="40px";
}


